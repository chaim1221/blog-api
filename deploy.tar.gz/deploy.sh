#!/bin/bash

create_release() {
  export fromtag="$FROMTAG"
  export merges=$(git log --merges --pretty=oneline $fromtag..HEAD | \
                  grep \# | \
                  awk '{print $7}' | \
                  uniq | \
                  awk 'BEGIN {RS="dn"} {gsub("\n","\\r\\n");print $0}')
  perl -p -e 's/MARKDOWN/$ENV{'merges'}/g' metadata.json > release.json
  curl -i -X POST \
       -H "Authorization: token $GIT_TOKEN" \
       -H "Content-Type: application/json" \
       -d @release.json \
          https://api.github.com/repos/chaim1221/blog-api/releases
}

### OUTER SCOPE ###
if [[ -z ${GIT_TOKEN} ]]; then
  echo ""
  echo "You must set the GIT_TOKEN environment variable to use this script."
  echo ""
  exit 1
fi
  create_release
fi
echo ""
echo "Done."
echo ""
